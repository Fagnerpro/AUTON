# Inicialização do pacote de banco de dados
from app.db import base_class as base
