from fastapi import APIRouter
from app.api.api_v1.endpoints import auth, users, organizations, simulations, reports

api_router = APIRouter()

# Incluir rotas de autenticação
api_router.include_router(
    auth.router, 
    prefix="/auth", 
    tags=["autenticação"]
)

# Incluir rotas de usuários
api_router.include_router(
    users.router, 
    prefix="/users", 
    tags=["usuários"]
)

# Incluir rotas de organizações
api_router.include_router(
    organizations.router, 
    prefix="/organizations", 
    tags=["organizações"]
)

# Incluir rotas de simulações
api_router.include_router(
    simulations.router, 
    prefix="/simulations", 
    tags=["simulações"]
)

# Incluir rotas de relatórios
api_router.include_router(
    reports.router, 
    prefix="/reports", 
    tags=["relatórios"]
)

