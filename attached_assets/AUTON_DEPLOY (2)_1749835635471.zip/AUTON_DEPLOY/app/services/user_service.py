def criar_usuario(nome: str, email: str, senha: str) -> dict:
    """
    Cria um dicionário simulando criação de usuário.
    """
    return {"nome": nome, "email": email, "senha": senha}
