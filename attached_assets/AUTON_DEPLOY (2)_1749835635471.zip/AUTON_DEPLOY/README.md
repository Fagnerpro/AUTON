
# 📦 Deploy do Projeto AUTON® – USINA I.A. (Hostinger)

## ✅ Requisitos do Servidor
- Acesso SSH
- Docker e Docker Compose instalados
- NGINX instalado e ativo
- Domínio configurado (ex: auton.usinaia.com.br)

---

## 🛠️ Passo a Passo

### 1. Acesso ao servidor
```bash
ssh usuario@IP_DO_SERVIDOR
```

### 2. Enviar arquivos e extrair
- Envie o `auton_deploy_hostinger.zip` via SFTP ou painel da Hostinger
```bash
unzip auton_deploy_hostinger.zip
cd auton_deploy_hostinger
```

### 3. Construir os containers
```bash
docker-compose up --build -d
```

### 4. Configurar o NGINX
Substitua o conteúdo do seu bloco de servidor por:

```nginx
server {
    listen 80;
    server_name auton.usinaia.com.br;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Reinicie o NGINX:
```bash
sudo systemctl restart nginx
```

### 5. (Opcional) Ativar HTTPS com Certbot
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d auton.usinaia.com.br
```

---

## 🔍 Teste Final
Acesse:
```
https://auton.usinaia.com.br/docs
```
Você verá a interface do Swagger UI da aplicação FastAPI.


---

## ⚙️ Frontend (Vite + React)

O serviço `frontend` está configurado com Node.js 18 em ambiente Docker. Ele executará os comandos abaixo automaticamente no container:

```bash
npm install
npm run dev
```

A aplicação React ficará acessível em:
```
http://localhost:3000/
```

Para build de produção (opcional), você pode executar:
```bash
npm run build
```

E configurar o NGINX para servir o conteúdo de `dist/`.

---
